LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_CFLAGS := -Wno-error=format-security  -w -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS := -Wno-error=format-security -w -Werror -s -std=gnu++17 -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive

LOCAL_C_INCLUDES += $(LOCAL_PATH)/次函数/include

FILE_LIST += $(wildcard $(LOCAL_PATH)/次函数/*.c*)
FILE_LIST += $(wildcard $(LOCAL_PATH)/主函数/*.c*)
LOCAL_MODULE :=CFM内核.sh

LOCAL_SRC_FILES := $(FILE_LIST:$(LOCAL_PATH)/%=%)

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2 -lGLESv3 -lGLESv1_CM -lz
include $(BUILD_EXECUTABLE)
