#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include "过缺页.h"
#include "字体.h"
uintptr_t 基址头;
pid_t 进程 = 0;

#if defined(__arm__)
int process_vm_readv_syscall = 376;
int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
int process_vm_readv_syscall = 270;
int process_vm_writev_syscall = 271;
#elif defined(__i386__)
int process_vm_readv_syscall = 347;
int process_vm_writev_syscall = 348;
#else
int process_vm_readv_syscall = 310;
int process_vm_writev_syscall = 311;
#endif

class c_driver
{
private:
    enum Mode { FILE_MODE, HOOK_MODE, SYS_MODE } mode;
    int fd;
    pid_t pid;

    // 文件模式专用成员
    int has_upper = 0;
    int has_lower = 0;
    int has_symbol = 0;
    int has_digit = 0;

    // 内存操作结构体
    typedef struct _COPY_MEMORY {
        pid_t pid;
        uintptr_t addr;
        void* buffer;
        size_t size;
    } COPY_MEMORY, *PCOPY_MEMORY;

    typedef struct _MODULE_BASE {
        pid_t pid;
        char* name;
        uintptr_t base;
    } MODULE_BASE, *PMODULE_BASE;

    // 文件模式操作码
    enum FILE_OPERATIONS {
    OP_INIT_KEY = 0x800,
    OP_READ_MEM = 0x801,
    OP_WRITE_MEM = 0x802,
    OP_MODULE_BASE = 0x803,
    OP_HIDE_PROCESS = 0x804,
};

    // Hook模式操作码
    enum HOOK_OPERATIONS
    {
        OP_HOOK_READ_MEM = 601,
        OP_HOOK_WRITE_MEM = 602,
        OP_HOOK_MODULE_BASE = 603,
        OP_HOOK_HIDE_PROCESS = 605,
    };

    // Syscall模式专用函数
    ssize_t process_v(pid_t __pid, const struct iovec *__local_iov, unsigned long __local_iov_count,
                      const struct iovec *__remote_iov, unsigned long __remote_iov_count,
                      unsigned long __flags, bool iswrite) {
        return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid,
                       __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
    }

    bool pvm(void *address, void *buffer, size_t size, bool iswrite) {
        struct iovec local[1];
        struct iovec remote[1];
        local[0].iov_base = buffer;
        local[0].iov_len = size;
        remote[0].iov_base = address;
        remote[0].iov_len = size;
        ssize_t bytes = process_v(pid, local, 1, remote, 1, 0, iswrite);
        return bytes == (ssize_t)size;
    }

    int symbol_file(const char *filename) {
		//判断文件名是否含小写并且不含大写不含数字不含符号
		int length = strlen(filename);
		for (int i = 0; i < length; i++) {
			if (islower(filename[i])) {
				has_lower = 1;
			} else if (isupper(filename[i])) {
				has_upper = 1;
			} else if (ispunct(filename[i])) {
				has_symbol = 1;
			} else if (isdigit(filename[i])) {
				has_digit = 1;
			}
		}
		return has_lower && !has_upper && !has_symbol && !has_digit;
	}

    char *driver_path() {
	// 打开目录
		const char *dev_path = "/dev";
		DIR *dir = opendir(dev_path);
		if (dir == NULL){
			printf("无法打开/dev目录\n");
			return NULL;
		}

		char *files[] = { "wanbai", "CheckMe", "Ckanri", "lanran","video188"};
		struct dirent *entry;
		char *file_path = NULL;
		while ((entry = readdir(dir)) != NULL) {
			// 跳过当前目录和上级目录
			if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
				continue;
			}

			size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
			file_path = (char *)malloc(path_length);
			snprintf(file_path, path_length, "%s/%s", dev_path, entry->d_name);
			for (int i = 0; i < 5; i++) {
				if (strcmp(entry->d_name, files[i]) == 0) {
					printf("驱动文件：%s\n", file_path);
					closedir(dir);
					return file_path;
				}
			}

			// 获取文件stat结构
			struct stat file_info;
			if (stat(file_path, &file_info) < 0) {
				free(file_path);
				file_path = NULL;
				continue;
			}

			// 跳过gpio接口
			if (strstr(entry->d_name, "gpiochip") != NULL) {
				free(file_path);
				file_path = NULL;
				continue;
			}

			// 检查是否为驱动文件
			if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
				&& strchr(entry->d_name, '_') == NULL && strchr(entry->d_name, '-') == NULL && strchr(entry->d_name, ':') == NULL) {
				// 过滤标准输入输出
				if (strcmp(entry->d_name, "stdin") == 0 || strcmp(entry->d_name, "stdout") == 0
					|| strcmp(entry->d_name, "stderr") == 0) {
					free(file_path);
					file_path = NULL;
					continue;
				}
				
				size_t file_name_length = strlen(entry->d_name);
				time_t current_time;
				time(&current_time);
				int current_year = localtime(&current_time)->tm_year + 1900;
				int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
				//跳过1980年前的文件
				if (file_year <= 1980) {
					free(file_path);
					file_path = NULL;
					continue;
				}
				
				time_t atime = file_info.st_atime;
				time_t ctime = file_info.st_ctime;
				// 检查最近访问时间和修改时间是否一致并且文件名是否是symbol文件
				if ((atime == ctime)/* && symbol_file(entry->d_name)*/) {
					//检查mode权限类型是否为S_IFREG(普通文件)和大小还有gid和uid是否为0(root)并且文件名称长度在7位或7位以下
					if ((file_info.st_mode & S_IFMT) == 8192 && file_info.st_size == 0
						&& file_info.st_gid == 0 && file_info.st_uid == 0 && file_name_length <= 9) {
						printf("驱动文件：%s\n", file_path);
						closedir(dir);
						return file_path;
					}
				}
			}
			free(file_path);
			file_path = NULL;
		}
		closedir(dir);
		return NULL;
	}

    // 文件模式初始化
    void init_file_mode() {
        char *device_name = driver_path();  // 先尝试/proc路径

        if (!device_name) {
            fprintf(stderr, "\033[1;31m [-] 找不到驱动 \033[0m\n");
            exit(EXIT_FAILURE);
        }

        printf("\033[1;32m[+] 找到驱动: %s \033[0m\n", device_name);
        fd = open(device_name, O_RDWR);
        hide_process();//隐藏进程
        free(device_name);

        if (fd == -1) {
            perror("\033[1;31m[-] 打开失败\033[0m");
            exit(EXIT_FAILURE);
        }
    }

    // Hook模式初始化
    void init_hook_mode() {
        fd = socket(AF_INET, SOCK_DGRAM, 0);
        if (fd == -1) {
            perror("\033[1;31m[-] 打开失败 \033[0m");
            exit(EXIT_FAILURE);
        }
        printf("\033[1;32m[+] Hook模式初始化成功 \033[0m\n");
    }

    // Syscall模式初始化
    void init_sys_mode() {
        fd = -1;  // Syscall模式不需要文件描述符
        printf("\033[1;32m[+] Syscall模式初始化成功 \033[0m\n");
    }

public:
    c_driver() {
        printf("\033[1;32m1. GT/RT驱动文件模式 (proc/dev)\033[0m\n");
        printf("\033[1;32m2. GT/RT驱动Hook模式 (Socket)\033[1;32m\n");
        printf("\033[1;31m3. Syscall模式 (无需驱动)\033[0m\n");
        printf("\033[1;36m选择读取模式:\033[0m");
        int mode_choice;
        scanf("%d", &mode_choice);
        
        if (mode_choice == 1) {
            mode = FILE_MODE;
            init_file_mode();
        } else if (mode_choice == 2) {
            mode = HOOK_MODE;
            init_hook_mode();
        } else {
            mode = SYS_MODE;
            init_sys_mode();
        }
    }

    ~c_driver() {
        if (fd > 0) close(fd);
    }

    void initialize(pid_t pid)
	{
		this->pid = pid;
	}

	bool init_key(char* key) {
		char buf[0x100];
		strcpy(buf,key);
		if (ioctl(fd, OP_INIT_KEY, buf) != 0) {
			return false;
		}
		return true;
	}

    // 通用读内存
    bool read(uintptr_t addr, void *buffer, size_t size) {
        if (mode == SYS_MODE) {
            return pvm(reinterpret_cast<void*>(addr), buffer, size, false);
        }
        
        COPY_MEMORY cm;
        cm.pid = pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;

        int opcode = (mode == FILE_MODE) ? 
            OP_READ_MEM : OP_HOOK_READ_MEM;
            
        return ioctl(fd, opcode, &cm) == 0;
    }

    // 通用写内存
    bool write(uintptr_t addr, void *buffer, size_t size) {
        if (mode == SYS_MODE) {
            return pvm(reinterpret_cast<void*>(addr), buffer, size, true);
        }
        
        COPY_MEMORY cm;
        cm.pid = pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;

        int opcode = (mode == FILE_MODE) ? 
            OP_WRITE_MEM : OP_HOOK_WRITE_MEM;
            
        return ioctl(fd, opcode, &cm) == 0;
    }

    template <typename T> 
    T read(uintptr_t addr) {
        T res;
        if (read(addr, &res, sizeof(T))) return res;
        return T{};
    }

    template <typename T> 
    bool write(uintptr_t addr, T value) {
        return write(addr, &value, sizeof(T));
    }
    
    void hide_process()
	{
		ioctl(fd, (mode == FILE_MODE) ? OP_HIDE_PROCESS : OP_HOOK_HIDE_PROCESS);
	}



    uintptr_t get_module_base(const char *name) {
        if (mode == SYS_MODE) {
            fprintf(stderr, "[-] Syscall模式不支持获取模块基址\n");
            return 0;
        }
        
        char buf[0x100];
        strcpy(buf, name);
        MODULE_BASE mb;
        mb.pid = pid;
        mb.name = buf;

        int opcode = (mode == FILE_MODE) ? 
            OP_MODULE_BASE : OP_HOOK_MODULE_BASE;
            
        if (ioctl(fd, opcode, &mb) != 0) {
            return 0;
        }
        return mb.base;
    }
};

static c_driver *driver = new c_driver();


typedef char PACKAGENAME;		// 包名
pid_t pid;						// 进程ID

float Kernel_v()
{
	const char* command = "uname -r | sed 's/\\.[^.]*$//g'";
	FILE* file = popen(command, "r");
	if (file == NULL) {
    	return NULL;
	}
	static char result[512];
	if (fgets(result, sizeof(result), file) == NULL) {
		return NULL;
	}
	pclose(file);
    result[strlen(result)-1] = '\0';
	return atof(result);
}

char *GetVersion(char* PackageName)
{
	char command[256];
	sprintf(command, "dumpsys package %s|grep versionName|sed 's/=/\\n/g'|tail -n 1", PackageName);
	FILE* file = popen(command, "r");
	if (file == NULL) {
		return NULL;
	}
	static char result[512];
	if (fgets(result, sizeof(result), file) == NULL) {
		return NULL;
	}
	pclose(file);
	result[strlen(result)-1] = '\0';
	return result;
}

uint64_t GetTime()
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC,&ts);
	return (ts.tv_sec*1000 + ts.tv_nsec/(1000*1000));
}

char *getDirectory()
{
	static char buf[128];
	int rslt = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
	if (rslt < 0 || (rslt >= sizeof(buf) - 1))
	{
		return NULL;
	}
	buf[rslt] = '\0';
	for (int i = rslt; i >= 0; i--)
	{
		if (buf[i] == '/')
		{
			buf[i] = '\0';
			break;
		}
	}
	return buf;
}

int getPID(char* PackageName)
{
	FILE* fp;
    char cmd[0x100] = "pidof ";
    strcat(cmd, PackageName);
    fp = popen(cmd,"r");
    fscanf(fp,"%d", &pid);
    pclose(fp);
	if (pid > 0)
	{
		driver->initialize(pid);
	}
    return pid;
}

bool PidExamIne()
{
	char path[128];
	sprintf(path, "/proc/%d",pid);
	if (access(path,F_OK) != 0)
	{
		printf("\033[31;1m");
		puts("获取进程PID失败!");
		exit(1);
	}
	return true;
}

long GetModuleBaseAddr(char *module_name)
{
	long addr = 0;
	char filename[32];
	char line[1024];
	if (pid < 0)
	{
		snprintf(filename, sizeof(filename), "/proc/self/maps", pid);
	}
	else
	{
		snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	}
	FILE *fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				sscanf(line, "%lx-%*lx", &addr);
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}

long getModuleBase(char *module_name)
{
	uintptr_t base = 0;
	if (Kernel_v() >= 6.0)
		base = GetModuleBaseAddr(module_name);
	else
		base = driver->get_module_base(module_name);
	return base;
}


long ReadValue(long addr)
{
	long he=0;
	if (addr < 0xFFFFFFFF){
		driver->read(addr, &he, 4);
	}else{
		driver->read(addr, &he, 8);
	}
	return he;
}

long ReadDword(long addr)
{
	long he=0;
	driver->read(addr, &he, 4);
	return he;
}

float ReadFloat(long addr)
{
	float he=0;
	driver->read(addr, &he, 4);
	return he;
}

int WriteDword(long int addr, int value)
{
	driver->write(addr, &value, 4);
	return 0;
}

int WriteFloat(long int addr, float value)
{
	driver->write(addr, &value, 4);
	return 0;
}
