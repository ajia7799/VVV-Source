/*

BYHCX死神

C语言的防破解可以从源码做起，一个小细节即可增加破解者难度，下面举例说明:不要用c++标准库，因为你会被破解者被找到方法，就是你必须要调用read函数进行读，你要read之前就比如调用open，你直接走系统调用，别走libc的，libc的导出函数open read也都是系统调用，这样的话，直接断libc.so的函数是断不到的，因为你根本没调用libc，这个东西你直接syscall就行，只是为了让别人不那么容易的处理你的反调试，因为大部分人调试器都装了插件，都把反调试检测函数给hook了，所以我们直接走系统调用，他们的插件就处理不掉了，还有就是代码不要用exit来退出，不要相信exit能给你退出，直接把你exit给nop掉从这个函数返回出来你的代码就会继续执行进入功能菜单，你可以杀掉自己，你也可以搞点异常代码，比如把一些重要的寄存器清零掉，调试捕获异常的时候大概率不在你处理的位置，你清零了，指不定啥时候出异常就导致很迷，就是A地的操作导致了B地的问题出现，需要让这个卡密登录跟你的功能关联一下，直接干掉你的验证你的功能都能单独跑，如果你的卡密是kami();这样放在main的，如果找到你的验证函数呢？直接把调用指令给nop了，直接验证都没了，相当于gg的--kami();比如你让这个登录里改一些变量，最简单的例子就是验证通过，修改一个变量值为一个数，然后用功能的时候判断一下那个变量，如果你有时间的话，可以把一些重要数据，比如偏移数据，基址数据放在服务器上，服务器那边判断你的卡密是你的正版用户，服务器就下发数据，你只要用到字符串即使你加密你就得解密不然没办法，你把字符串加密了，但是没法正常用，那你加密他干啥，运行的时候就会解密才能运行，动态调试是无法阻挡的，这些做好，你才算是没逻辑上的漏洞，最好是不要封装方法，如果非要这么弄，最好看看有没有那种关键字，就是强制内联的那种，比如msvc编译器的__forceinline，所以你可以看看gcc或clang的编译器，可以用__attribute__((always_inline))，唉写累了不想在写下去了，有能力的人继续优化吧，调用方法executeProgram();写main里*/
#ifndef EXECUTE_PROGRAM_H
#define EXECUTE_PROGRAM_H

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <dirent.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <cstdlib>
#include <ctime>
#include <fcntl.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <cstring>
#include <thread>
#include <chrono>


// 函数用于检测当前进程是否在调试状态
inline __attribute__((always_inline)) bool isDebuggerPresent() {
    int statusFile = syscall(SYS_openat, "/proc/self/status", O_RDONLY);
    char buffer[4096];
    std::string line;
    ssize_t bytesRead;
    while ((bytesRead = syscall(SYS_read, statusFile, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[bytesRead] = '\0';
        line += buffer;
        if (line.find("TracerPid") != std::string::npos) {
            std::istringstream iss(line);
            std::string label;
            int value;
            iss >> label >> value;
            if (value != 0) {
                syscall(SYS_close, statusFile);
                return true;
            }
            break;
        }
    }
    syscall(SYS_close, statusFile);
    return false;
}



// 检查当前程序是否正在被调试，并设置随机的程序名称
inline __attribute__((always_inline)) bool isBeingDebugged() {
    std::string randomName = "program_" + std::to_string(std::rand());
   // prctl(PR_SET_NAME, randomName.c_str(), 0, 0, 0);
    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    return ptrace(PTRACE_TRACEME, 0, nullptr, nullptr) == -1;
}


// 用于退出程序的信号处理函数
inline __attribute__((always_inline)) void exitProgram(int signal) {
    kill(getpid(), SIGKILL);
}

// 执行程序的主要逻辑
inline __attribute__((always_inline)) void executeProgram() {
    std::srand(std::time(nullptr));

    // 检查当前程序是否存在调试器
    if (isDebuggerPresent()) {
        exitProgram(0);
        return;
    }

    // 检查当前程序是否正在被调试
   /* if (isBeingDebugged()) {
        std::cout << "程序被调试器附加！程序即将退出。" << std::endl;
        exitProgram(0);
        return;
    }*/

    // 目的是为了增加调试的困难性。通过计算循环，可以使调试器在调试过程中变得更加困难，在调试过程中会逐行执行代码并监视变量的值。
    // 通过添加计算循环，可以使调试器需要更长的时间才能完成执行，因为它必须逐步执行循环中的每个迭代，如果运行时间长可以改小范围
    int result = 0;
    for (int i = 0; i < 10000000; ++i) {
        result += i;
    }

    // 检查运行时的进程信息，查看是否有调试器进程存在
    DIR* dir;
    struct dirent* entry;
    bool debuggerProcessFound = false;

    if ((dir = opendir("/proc")) != nullptr) {
        while ((entry = readdir(dir)) != nullptr) {
            std::string procDirName = entry->d_name;
            if (procDirName != "." && procDirName != "..") {
                std::string procPath = "/proc/" + procDirName;
                int cmdlineFile = syscall(SYS_openat, (procPath + "/cmdline").c_str(), O_RDONLY);
                char buffer[4096];
                ssize_t bytesRead = syscall(SYS_read, cmdlineFile, buffer, sizeof(buffer) - 1);
                if (bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    std::string cmdline(buffer);
                    if (cmdline.find("gdb") != std::string::npos || cmdline.find("lldb") != std::string::npos) {
                        debuggerProcessFound = true;
                        break;
                    }
                }
                syscall(SYS_close, cmdlineFile);
            }
        }
        closedir(dir);
    }

    if (debuggerProcessFound) {
        exitProgram(0);
        return;
    }

    
      // 检测父进程是否是调试器进程
    pid_t parentPid = getppid();
    std::string parentStatusFilePath = "/proc/" + std::to_string(parentPid) + "/status";
    int parentStatusFile = syscall(SYS_openat, parentStatusFilePath.c_str(), O_RDONLY);
    char buffer[4096];
    std::string parentLine;
    ssize_t bytesRead;
    while ((bytesRead = syscall(SYS_read, parentStatusFile, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[bytesRead] = '\0';
        parentLine += buffer;
        if (parentLine.find("TracerPid") != std::string::npos) {
            std::istringstream iss(parentLine);
            std::string label;
            int value;
            iss >> label >> value;
            if (value != 0) {
                syscall(SYS_close, parentStatusFile);
                exitProgram(0);
                return;
            }
            break;
        }
    }
    syscall(SYS_close, parentStatusFile);

}

 

#endif  // EXECUTE_PROGRAM_H