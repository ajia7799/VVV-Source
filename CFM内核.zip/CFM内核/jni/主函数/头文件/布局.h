void tick()
{   
    ImGuiIO& io = ImGui::GetIO();
    //音量();
    if (display == EGL_NO_DISPLAY)
    return;
    static ImVec4 clear_color = ImVec4(0, 0, 0, 0);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(init_screen_x, init_screen_y);
    ImGui::NewFrame();
    {
		
        	ImGui::Begin(ICON_FA_ASTERISK" CFM ESP 内核测试 ");{
        	ImGui::Text("基地址 %p",基址头);
			ImGui::Text("阵列 %p",对象阵列);
			ImGui::Text("自身 %p",自身对象);			
			ImGui::Text("当前数量 %d",数量);
			ImGui::Text("开镜 %d",开镜);			
			ImGui::Text("开火 %d",开火);		
			ImGui::Text(ICON_FA_USER_CIRCLE " by:无心  演戏上分即可");
			if (ImGui::Combo("", &style_idx, "白色主题\0蓝色主题\0紫色主题\0"))
            {
            switch (style_idx)
            {
              case 0: ImGui::StyleColorsLight(); break;
              case 1: ImGui::StyleColorsDark(); break;
              case 2: ImGui::StyleColorsClassic(); break;
            }
            }
            if (style_idx == 0){
            ImGui::StyleColorsLight();
            }
            if (style_idx == 1){
            ImGui::StyleColorsDark();
            }
            if (style_idx == 2){
            ImGui::StyleColorsClassic();
            }
			ImGui::Text("帧率平均值 %.3f ms/帧率 %.1f FPS", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
			if (ImGui::Button("\xef\x81\x82 初始",{100,55}))   
			{    
		    int intauto = DrawInt();
	        if (intauto == 0)
		    {
			cshzt = true;
			DrawIo[0] = true;
			}
			}
			ImGui::SameLine();
            if(人物)
            {
            if (ImGui::Button(ICON_FA_GAMEPAD"透视[已启动]",{160,55}))   
            {    
            DrawIo[1]=false;
            人物 = false;
            }
            }else{
            if (ImGui::Button(ICON_FA_GAMEPAD"透视[未启动]",{160,55}))   
            {    
            DrawIo[1]=true;        
            人物 = true;
            }
            }             
            ImGui::SameLine();       
            if(触摸自瞄)
            {
            if (ImGui::Button(ICON_FA_CROSSHAIRS"自瞄[已启动]",{160,55}))   
            {    
            DrawIo[2]=false;
            触摸自瞄 = false;
            }
            }else{
            if (ImGui::Button(ICON_FA_CROSSHAIRS"自瞄[未启动]",{160,55}))   
            {    
            DrawIo[2]=true;        
            触摸自瞄 = true;
            }
            }
            if (ImGui::Button(ICON_FA_CROSSHAIRS"描边(危险)",{160,55})){
            WriteDword(基址头+0x3B08550, 1384120352);
            WriteDword(基址头+0x7358da8, 1384120320);
            WriteDword(基址头+0x814FD64, 1384120353);
            WriteDword(基址头+0x814FD70, 506335234);
            }


         ImGui::Text("阵容选择(对局内开启)");
         ImGui::RadioButton("警方", &NumIo[49], 0.0f); 
		 ImGui::SameLine();
		 ImGui::RadioButton("匪方", &NumIo[49], 1.0f);
		 ImGui::SameLine();
		 ImGui::RadioButton("生存", &NumIo[49], 2.0f);		 
		 
	   	ImGui::RadioButton("坐标1", &坐标切换, 1); 
		 ImGui::SameLine();
		 ImGui::RadioButton("坐标2", &坐标切换, 2);
		 ImGui::SameLine();
		 ImGui::RadioButton("坐标3", &坐标切换, 3);		 
		 
      	ImGui::RadioButton("数组1", &数组切换, 1); 
		 ImGui::SameLine();
		 ImGui::RadioButton("数组2", &数组切换, 2);	 
		 
		 ImGui::Checkbox("触摸位置", &DrawIo[21]);
		 ImGui::SliderFloat("自瞄范围", &NumIo[3], 0.0f, 500.0f,"%.1f",1);     
         ImGui::SliderFloat("自瞄速度", &NumIo[4],0.1f,50.0f,"%.2f",2);
	     ImGui::SliderFloat("子弹速度", &NumIo[11],500.0f,1200.0f,"%.0f",3);
		 ImGui::SliderFloat("平滑力度", &NumIo[9],0.1f,30.0f,"%.1f",3);
	 	 ImGui::RadioButton(混淆("锁死"), &NumIo[0], 0.0f);
	     ImGui::SameLine();
		 ImGui::RadioButton(混淆("开火"), &NumIo[0], 1.0f);
	     ImGui::SameLine();
		 ImGui::RadioButton(混淆("开镜"), &NumIo[0], 2.0f);		 
	     ImGui::SameLine();
		 ImGui::RadioButton(混淆("开镜开火"), &NumIo[0], 3.0f);		 		 
		 if (ImGui::Button("关闭辅助")){
		 exit(0);
		 }
         }


    }
	if(cshzt)
   	DrawPlayer(ImGui::GetForegroundDrawList()); 	
    ImGui::Render();  
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    glClearColor(clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}

void shutdown()
{
    if (!g_Initialized) {
        return;
    }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    if (display != EGL_NO_DISPLAY){
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT){
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE){
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;
    ANativeWindow_release(native_window);
}
