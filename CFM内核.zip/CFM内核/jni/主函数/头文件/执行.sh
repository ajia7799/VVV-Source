#!/system/bin/bash


outfile="file.txt"      # 输出文件名

# 清空 / 新建输出文件
: > "$outfile"

# 构造 find 过滤条件：目标后缀 & 排除 outfile
find . -maxdepth 1 -type f \
      \( -iname '*.c' -o -iname '*.cpp' -o -iname '*.h' -o -iname '*.hpp' -o -iname '*.mk' \) \
      ! -name "$(basename "$outfile")" -print0 |
while IFS= read -r -d '' file; do
    printf '这是%s：\n' "$(basename "$file")" >> "$outfile"
    cat "$file" >> "$outfile"
    printf '\n\n' >> "$outfile"
done