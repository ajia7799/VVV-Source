#include <draw.h>
#include "头文件/混淆.h"
#include "头文件/反调试.h"
#include "头文件/函数.h"
#include "头文件/定函数.h"
#include "头文件/源码库.hpp"
#include "头文件/布局.h"
#include "头文件/触摸自瞄.hpp"

static bool 记录 = false;


pid_t get_name_pid(char* name) {
    FILE* fp;
    pid_t pid;
    char cmd[0x100] = "pidof ";

    strcat(cmd, name);
    fp = popen(cmd,"r");
    fscanf(fp,"%d", &pid);
    pclose(fp);
    return pid;
}

int DrawInt()
{
    进程 = getPID((char*)"com.tencent.tmgp.cf");
    if(进程<=0){
    printf("\n [>]请先启动游戏！\n");
    exit(1);    
    }
    driver->initialize(进程);    
    基址头 = getModuleBase((char*)"libil2cpp.so");
    return 0;
}

void DrawPlayer(ImDrawList *画图)
{
    py = screen_y/2;
    px = screen_x/2;
	float top,right,left,bottom,XLX,MIDDLE;
    if (DrawIo[2])       
    {         
    画图->AddRect({px - NumIo[3],py - NumIo[3]},{px + NumIo[3],py +NumIo[3]},红色);
    }   
	
	if (DrawIo[21])
    {	
    画图->AddRectFilled({0,0}, {px*2, py*2},ImColor(0,0,0,110));
    std::string ssf;
    ssf += "触摸位置";
    auto textSize = ImGui::CalcTextSize(ssf.c_str(), 0, 25);
    画图->AddRectFilled({NumIo[6] - NumIo[7]/2, py*2 - NumIo[5] + NumIo[7]/2}, {NumIo[6] + NumIo[7]/2, py*2 - NumIo[5] - NumIo[7]/2},ImColor(255,0,0,120)); 
	画图->AddText(NULL,32,{NumIo[6] - (textSize.x / 2),py*2 - NumIo[5]},ImColor(255,255,255),ssf.c_str());                                                   
    }  
    矩阵 =ReadValue(ReadValue(ReadValue(ReadValue(基址头+0xCFDA0D0)+0xa0)+0x10)+0x10)+0xC8;
    if (数组切换 == 1){
        数量 = ReadDword(ReadValue(ReadValue(ReadValue(ReadValue(基址头+0xCFDC0D0)+0xA0)+0x10) + 0x10)+0x18);
        数组 = ReadValue(ReadValue(ReadValue(ReadValue(ReadValue(基址头+0xCFDC0D0)+0xA0)+0x10) + 0x10)+0x10);
    }else if (数组切换 == 2){
        数量 = ReadDword(ReadValue(ReadValue(ReadValue(ReadValue(ReadValue(基址头+0xCFDEF18)+0xa0)+0x28) + 0x50)+0x70) + 0x18);
        数组 = ReadValue(ReadValue(ReadValue(ReadValue(ReadValue(ReadValue(基址头+0xCFDEF18)+0xa0)+0x28) + 0x50)+0x70) + 0x10);
    }
    对象阵列 = 数组+0x20;
    
	自身队伍 = 2;
	if (DrawIo[1]){
	if(NumIo[49]==0){
    自身队伍 = 1;	
	}else if(NumIo[49]==1){
	自身队伍 = 2;		
	}
	}
	
    memset(matrix, 0, 16);
    driver->read(矩阵, matrix, 16 * 4);
	人物数量=0;
    瞄准数量=0;
    for (int i = 0; i <数量; i++)
    {
        对象指针 = ReadValue(对象阵列 + 8 * i);
        long int zjzzc = ReadValue(ReadValue(ReadValue(自身对象 + 0x408) + 0x20) + 0x10);//protected PawnAnimationComponent m_AnimationComponent;      private Animator m_Animator;    
		long int zzc = ReadValue(ReadValue(ReadValue(对象指针 + 0x408) + 0x20) + 0x10);

        if (ReadDword(ReadValue(对象指针+0x430)+0x10c) != 0){  //PlayerInfo m_PlayerInfo    private UInt16 m_Ping;
           自身对象 = 对象指针;
        }
        
        开镜= ReadValue(自身对象 + 0x7c);  //开镜   protected Boolean m_IsHidden;
		开火 = ReadDword(ReadValue(自身对象 + 0x148) + 0xb0);//protected SpectatorComponent m_SpectatorComponent;    private Boolean m_IsFiring;
		//m_IsFiring
        Vector3A 自身, 敌人;
        if (坐标切换==1){
        driver->read(zjzzc+0x324,&自身,sizeof(自身));//330
        driver->read(zzc+0x324,&敌人,sizeof(敌人)); // 对象坐标      
        }else if (坐标切换 == 2){
        driver->read(zjzzc+0x330,&自身,sizeof(自身));//330
        driver->read(zzc+0x330,&敌人,sizeof(敌人)); // 对象坐标      
        }
		camera = matrix[3] * 敌人.X + matrix[7] * 敌人.Z + matrix[11] * 敌人.Y + matrix[15];
	    r_x = px + (matrix[0] * 敌人.X + matrix[4] * (敌人.Z) + matrix[8] * 敌人.Y + matrix[12]) / camera * px;	// 视角高
	    r_y = py - (matrix[1] * 敌人.X + matrix[5] * (敌人.Z + 0.5) + matrix[9] * 敌人.Y + matrix[13]) / camera * py;	// ;视角宽
	    r_w = py - (matrix[1] * 敌人.X + matrix[5] * (敌人.Z + 1.5) + matrix[9] * 敌人.Y + matrix[13]) / camera * py;							  
        X = r_x - (r_y - r_w) / 4;
        Y = r_y;
        W = (r_y - r_w) / 2;
		float XLX = r_x - (r_y - r_w) / 85;
        top = Y-W;
        bottom = Y+W;
		float MIDDLE = X + W/2;
        left = MIDDLE-(W/2);
        right = MIDDLE+(W/2);
		float pmjl = sqrt(pow(r_x - px, 2) + pow(r_y - py, 2));
        double 距离 =sqrt(pow(敌人.X - 自身.X, 2) + pow(敌人.Z - 自身.Z, 2) + pow(敌人.Y - 自身.Y, 2));
	    
        对象阵营=ReadDword(ReadValue(对象指针+0x430)+0x138);
        人物血量 =ReadFloat(ReadValue(对象指针 + 0x430) + 0x154)/(float)(ReadDword(ReadValue(对象指针 + 0x430) + 0x158))*100;  //68备用   
        if (自身队伍 == 对象阵营 && NumIo[49]!=2)
        {
          continue;
        }
		
        if (对象阵营 <= 0)
        {
        continue;
        }      
		
        if (人物血量==0)
        {
          continue;
        }
		
		if (人物血量 < 0)
		{
		  continue;
		}
		
		getUTF8(名字, ReadValue(ReadValue(对象指针 + 0x430)+0x70)+0x14);//  protected String m_NickName;     
//错误		
	
        if (W>0){
        if (DrawIo[2]){
        瞄准[瞄准数量].瞄准目标=敌人;
        瞄准[瞄准数量].自身目标 = 自身;
        瞄准[瞄准数量].判断距离 = 距离;
        瞄准[瞄准数量].准心最近距离 = sqrt(pow(px - r_x,2)+pow(py-(Y - W/1.5),1));
        //预瞄点👇
        画图->AddCircleFilled({px, py}, {3},白色);
        if(获取目标()==瞄准数量){       
	    DrawLine(px,py,MIDDLE,Y+W/2-20, 1.0f,0,1.0f,0.8f,3);
        }    
        瞄准数量++;
        }
        }
        if (W>0){
        if (DrawIo[1]){	
		
		DrawRect(left,top,right,bottom,RectColor, 0, 2.2f);
		
	    DrawRectFilled(X-5,Y+W-((Y+W)-(Y-W))*人物血量/100,X-10,Y+W,1.0f,0.86f,1.0f,1.0f);
               
		if (名称显示){
				//信息
				std::string ss;
				ss += "队伍";
           		ss += std::to_string(对象阵营);
				ss += " － ";
				ss += 名字;
				auto textSize = ImGui::CalcTextSize(ss.c_str(), 0, 28.f);
           		ImGui::GetForegroundDrawList()->AddText(NULL, 25.f, {MIDDLE - 15, top - 65},白色, ss.c_str());
	   }
		std::string s;
		s += std::to_string((int)距离);s += "m";
		auto textSize = ImGui::CalcTextSize(s.c_str(), 0, 28.f);
	    ImGui::GetForegroundDrawList()->AddText(NULL, 25.f, {MIDDLE - 15, top - 45},白色, s.c_str());        		  
		}
        }//绘图区
		人物数量++;
		
}
        全部数量=瞄准数量;
        char extras[250];
        sprintf(extras, "PlayerCount:%d", 人物数量);
	    绘制字体描边(35.0f, px-100,140.0f, 白色, extras);   
}
