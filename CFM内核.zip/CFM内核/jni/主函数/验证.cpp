#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <fstream>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <iostream>
#include <fstream>
#include <sys/system_properties.h>
#include "网络验证/微验.h"
#include <ctime>
#include <main.h>
#include <stdlib.h>
#include <exception>
#include <fstream>
#include <iostream>
#include <sstream>
#include <linux/input.h>
#include <dirent.h>

using namespace std;
int main(int argc, char **argv)
{
/*    system(混淆("rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.cf/files/tencent/mobileqq/opensdk/logs/ 2> /dev/null"));
    system(混淆("rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.cf/files/log/ 2> /dev/null"));
    system(混淆("rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.cf/files/tbslog/ 2> /dev/null"));
    system(混淆("rm -rf /data/user/0/com.tencent.tmgp.cf/files/log/ 2> /dev/null"));
    system(混淆("rm -rf /data/user/0/com.tencent.tmgp.cf/files/EstvShadowPlugin_shadow-app/xlog/ 2> /dev/null"));
    system(混淆("rm -rf /data/user/0/com.tencent.tmgp.cf/files/initcfm.log 2> /dev/null"));
    system(混淆("rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.cf/files/midas/log/com.tencent.tmgp.cf/ 2> /dev/null"));
    system(混淆("rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.cf/files/MSDKLog.log.0 2> /dev/null"));*/
    
    微验验证();
    screen_config();
    init_screen_x = screen_x + screen_y;
    init_screen_y = screen_y + screen_x;
	if(!init_egl(init_screen_x,init_screen_y)) 
	{
     exit(0);
    }
    ImGui_init();
    new std::thread(Getxfctouch);
	new std::thread(Getxfctouch2);
	new std::thread(AimBotAuto,ImGui::GetForegroundDrawList());
    while (1)
    {     	
	 tick();  
	}
    shutdown();
    return 0;
}
